
public class FirstClass {

	public void fc_m1(){
	}
	
	public void fc_m2(){
		this.fc_m1();
		this.fc_m1();
	}
}


